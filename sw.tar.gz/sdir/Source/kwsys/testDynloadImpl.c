/* Distributed under the OSI-approved BSD 3-Clause License.  See accompanying
   file Copyright.txt or https://cmake.org/licensing#kwsys for details.  */

#include "testDynloadImpl.h"

int TestDynamicLoaderImplData = 0;

void TestDynamicLoaderImplSymbolPointer()
{
}
